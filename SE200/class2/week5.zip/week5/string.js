// console.log(str.length);

// console.log(str.charAt(21));

// const arr = str.split(' ').join('-');

// console.log(arr);

// console.log(str.concat(arr, ' joke', ' haha', 'world'));

// console.log(str.includes('sb'));

// console.log(str.indexOf('b'));

// console.log(str.match(\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b))
const str = 'United States of China         ';

// console.log(str.slice(1, 5));
// console.log(str.substring(0, ))

console.log(str, str.trim(), str);
