let a = 0;
let b = 1;

function trumpify(name, callback) {
	result = name + ' Trump' + a;
	b = 2;
	console.log(callback(name));
	return result;
}

function dudify(name) {
	return name + ' dude';
}

const poopify = name => name + ' poop';

let result = 1;
const test1 = trumpify('Kaina', dudify);

console.log(test1);
