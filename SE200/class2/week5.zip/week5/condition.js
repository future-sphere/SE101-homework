// const isLegalToDrink = age => {
// 	if (+age >= 21) {
// 		console.log(age);
// 		return true;
// 	} else if (age > 21 && age < 30) {
// 		// do something else
// 	} else if (age > 30 || age < 60) {
// 	} else {
// 		// everything else
// 	}
// };

const getLetterGradeFromScore = score => {
	switch (true) {
		case score < 60:
			return 'F';
		case score >= 60 && score < 70:
			return 'D';
		case score >= 70 && score < 80:
			return 'C';
		case score >= 80 && score < 90:
			return 'B';
		case score >= 90:
			return 'A';
		default:
			return 'nb';
			break;
	}
};
const willScore = 77.5;
console.log(getLetterGradeFromScore(willScore));

// const peterAge = 21;

// const isPeterLegalToDrink = isLegalToDrink(peterAge);

// if (isPeterLegalToDrink) {
//   // show allow to drink icon
// } else {
//   // kick the user off the site
// }

// const str = 'hello world';
// str[0] = 'H';
// str.splice(0, 1);

// const food = ['apple', 'orange', 'pear'];

// const capitalize = name => name[0].toUpperCase() + name.slice(1).toLowerCase();

// const mergeName = (firstName, lastName) =>
// 	capitalize(firstName) + ' ' + capitalize(lastName);

// const greeting = guestName => 'Welcome, ' + guestName;

// const greetingText = greeting(mergeName('peTeR', 'zHEnG'));

// const test = () => {
// 	const dummyInput = 'peTeR';
// 	const expectedOutput = 'Peter';
// 	expect(capitalize(dummyInput) === expectedOutput);
// };

// console.log(greetingText);

// > < >= >== <= <== == === != !==

// x == y : is x equal to y in value?
// x === y : is x equal to y in value and type?

// const x = 2;
// const y = "2";

// x == y , x != y

// x === y , x !== y

// const number = 6466397087
// const numberInString = "6466397087";

// if (number !== numberInString) {
//   return false;
// }
