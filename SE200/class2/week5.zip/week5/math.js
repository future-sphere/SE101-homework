const n = 10;
const x = 4;
const y = -20;
const a = 3.14;

// console.log(Math.PI);

// console.log(Math.abs(y));

// console.log(Math.ceil(a));

// console.log(Math.floor(a));

// console.log(Math.exp(a));

// console.log(Math.round(a));

// console.log(Math.random());

// console.log(Math.pow(x, 4));

const findRandomNumberWithMinAndMax = (min, max) => {
  const result = .....;
  return result;
}

console.log(Math.sqrt(x));
