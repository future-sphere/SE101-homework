const num = '56';

// console.log(isNaN(num));

// console.log(Number.isInteger(num));

// console.log(num.toFixed(1));

// console.log(num.toString());

console.log(1 + +num);
