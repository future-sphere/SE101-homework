let x = 10; //number;
const y = 10; //number;
var z = 12;

x = x + 1;
// y = y + 1; //  cannot do that

console.log(x, y);

/*
 code 
*/

const name = 'peter';
// string

const isMarried = false;
// boolean

const favoriteFood = ['Chicken over rice', 'Cheese Burger', 'Pizza'];

const jen = {
	firstName: 'Jen',
	lastName: 'Liang',
	birthMonth: 'April',
	money: 10,
	isMarried: false,
	favoriteFood: ['Chicken Over Rice', 'Bubble Tea', 'Apple'],
	school: {
		name: 'Baruch College',
		city: 'New York City',
		graduationYear: 2019,
		president: {
			firstName: 'John',
			lastName: 'Doe',
			age: 55,
			favoriteDrink: ['Martini', 'Corona'],
		},
	},
};

console.log(jen.money, jen.school.name);
console.log(jen.school.president.favoriteDrink[0]);
console.log(jen.school.president.age);

jen.school.name = 'City College'; // ok
// jen = {
// 	firstName: 'Peter',
// }; // bu ok

jen.lastName = 'Zheng';
jen.lastName = 'Yang';
jen.lastName = jen.firstName;

jen.favoriteFood[0] = 'Lamb over rice';
jen.favoriteFood[1] = 'oolong tea';
jen.favoriteFood.push('Fujian ren');
jen.favoriteFood.splice(2, 2, '新疆人', '河南人'); // delete the item in index 2
jen.favoriteFood.unshift('广东人');
jen.favoriteFood.splice(2, 0, '武汉人');

['Lamb over rice', 'oolong tea', 'Apple', 'Fujian ren'];

['广东人', 'Lamb over rice', 'oolong Tea', '新疆人', '河南人'];

console.log(jen.favoriteFood);

// const x = [
// 	['x', 'o', 'x'],
// 	['x', 'x', 'o'],
// 	['o', 'o', 'x'],
// ];

// function tictactoe(board) {
// 	code;

// 	return 'x' || 'o' || false;
// }

// (x[0][0] == x[1][1]) == x[2][2];
// (x[0][2] == x[1][1]) == x[2][0];
