const x = 10;
const y = 3;

const z = x / y;

const w = x % y;

console.log(z);

console.log(w); // 1

// x % 2 = 0;

// 1.
console.log(w);

// 2.
document.write(w);

// 3.
window.alert(w);

// 4.
document.getElementById('demo').innerHTML = w;
