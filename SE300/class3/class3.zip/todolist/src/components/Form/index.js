import React, { Component } from 'react';

class Form extends Component {
	state = {
		data: '',
	};
	render() {
		return (
			<div>
				<input
					value={this.state.data}
					onChange={e => {
						this.setState({
							data: e.target.value,
						});
					}}
					type='text'
				/>
				<button
					onClick={() => {
						console.log(this.state.data);
						this.setState(
							{
								data: '',
							},
							() => {
								console.log(this.state.data);
							},
						);
					}}>
					Submit
				</button>
			</div>
		);
	}
}

export default Form;
