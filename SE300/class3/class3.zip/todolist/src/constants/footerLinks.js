const footerLinks = [
	[
		{
			label: 'Company',
			link: 'https://google.com',
		},
		{
			label: 'Company2',
			link: 'https://googl2e.com',
		},
		{
			label: 'Company3',
			link: 'https://google1.com',
		},
		{
			label: 'Company4',
			link: 'https://googl3e.com',
		},
	],
	[
		{
			label: 'Company4',
			link: 'https://googl3e.com',
		},
		{
			label: 'Company4',
			link: 'https://googl3e.com',
		},
	],
	[
		{
			label: 'Kaina',
			link: 'kaina.com',
		},
		{
			label: 'Sheldon',
			link: 'kaina.com',
		},
		{
			label: 'Will',
			link: 'kaina.com',
		},
		{
			label: 'Toby',
			link: 'kaina.com',
		},
	],
];

// export const z = 5;

// export const x = 10;
// export const y = 20;

export default footerLinks;
