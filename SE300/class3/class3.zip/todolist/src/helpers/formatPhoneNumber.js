export const format = num => {
	return num.split('').join('');
};
