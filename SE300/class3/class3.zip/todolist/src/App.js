import React from 'react';
import logo from './logo.svg';
import './App.css';
import footerLinks from './constants/footerLinks';
import Form from './components/Form';

function App() {
	return (
		<div className='App'>
			<Form />
			{/* {footerLinks.map(v => {
				return (
					<div style={{ display: 'inline-block' }}>
						{v.map(item => {
							return (
								<a style={{ display: 'block' }} href={item.link}>
									{item.label}
								</a>
							);
						})}
					</div>
				);
			})} */}
		</div>
	);
}

export default App;
