const skinUrl = 'http://ddragon.leagueoflegends.com/cdn/img/champion/splash/';

export default skinUrl;
